<div class="checkout-left-content">
  <div class="dimmer active">  
    <div class="loader"></div>
    <div class="dimmer-content">
	    <script type="text/javascript">
			window.location.assign("<?php echo $redirect_url; ?>");
		</script>
   	</div>
  </div>
</div>
